import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../constants/colors.dart';
import '../models/class_schedule.dart';
import '../store/class_schedule_store.dart';

// ─────────────────────────────────────────────────────────────
// Entry point
// ─────────────────────────────────────────────────────────────
void showClassAlertsSheet(BuildContext context) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    enableDrag: true,
    builder: (_) => const ClassAlertsSheet(),
  );
}

// ─────────────────────────────────────────────────────────────
// Sheet
// ─────────────────────────────────────────────────────────────
class ClassAlertsSheet extends StatefulWidget {
  const ClassAlertsSheet({super.key});

  @override
  State<ClassAlertsSheet> createState() => _ClassAlertsSheetState();
}

class _ClassAlertsSheetState extends State<ClassAlertsSheet>
    with SingleTickerProviderStateMixin {
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;

  bool _showAddForm = false;

  @override
  void initState() {
    super.initState();
    _fadeCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 260));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();
    ClassScheduleStore.instance.addListener(_onStoreChanged);
  }

  void _onStoreChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    ClassScheduleStore.instance.removeListener(_onStoreChanged);
    _fadeCtrl.dispose();
    super.dispose();
  }

  void _openAddForm() => setState(() => _showAddForm = true);
  void _closeAddForm() => setState(() => _showAddForm = false);

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);

    return FadeTransition(
      opacity: _fadeAnim,
      child: Container(
        height: mq.size.height * 0.88,
        decoration: const BoxDecoration(
          color: Color(0xFF1A2D5A),
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
        child: Column(
          children: [
            // ── Handle ────────────────────────────────────
            Container(
              width: 36, height: 4,
              margin: const EdgeInsets.only(top: 12),
              decoration: BoxDecoration(
                color: kWhite.withOpacity(0.18),
                borderRadius: BorderRadius.circular(2),
              ),
            ),

            // ── Header ────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 16, 0),
              child: Row(
                children: [
                  Container(
                    width: 42, height: 42,
                    decoration: BoxDecoration(
                      color: kTeal.withOpacity(0.14),
                      shape: BoxShape.circle,
                      border: Border.all(color: kTeal.withOpacity(0.3), width: 1.5),
                    ),
                    child: const Icon(Icons.school_rounded, color: kTeal, size: 21),
                  ),
                  const SizedBox(width: 13),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Class Alerts',
                          style: TextStyle(
                              color: kWhite, fontSize: 17, fontWeight: FontWeight.bold)),
                      Text('Your weekly class schedule',
                          style: TextStyle(color: kWhite.withOpacity(0.4), fontSize: 12)),
                    ],
                  ),
                  const Spacer(),
                  // Add button
                  if (!_showAddForm)
                    GestureDetector(
                      onTap: _openAddForm,
                      child: Container(
                        width: 34, height: 34,
                        decoration: BoxDecoration(
                          color: kTeal.withOpacity(0.15),
                          shape: BoxShape.circle,
                          border: Border.all(color: kTeal.withOpacity(0.35)),
                        ),
                        child: const Icon(Icons.add_rounded, color: kTeal, size: 20),
                      ),
                    ),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      width: 32, height: 32,
                      decoration: BoxDecoration(
                        color: kWhite.withOpacity(0.07),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(Icons.close_rounded,
                          color: kWhite.withOpacity(0.5), size: 17),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),
            Divider(height: 1, color: kWhite.withOpacity(0.07)),

            // ── Body ──────────────────────────────────────
            Expanded(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 220),
                child: _showAddForm
                    ? _AddClassForm(
                        key: const ValueKey('form'),
                        onSaved: _closeAddForm,
                        onCancel: _closeAddForm,
                      )
                    : _ScheduleList(
                        key: const ValueKey('list'),
                        onAdd: _openAddForm,
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
// Schedule list view
// ─────────────────────────────────────────────────────────────
class _ScheduleList extends StatelessWidget {
  final VoidCallback onAdd;

  const _ScheduleList({super.key, required this.onAdd});

  @override
  Widget build(BuildContext context) {
    final schedules = ClassScheduleStore.instance.schedules;

    if (schedules.isEmpty) {
      return _EmptyState(onAdd: onAdd);
    }

    // Group by day
    final Map<int, List<ClassSchedule>> byDay = {};
    for (final s in schedules) {
      for (final d in s.days) {
        byDay.putIfAbsent(d, () => []).add(s);
      }
    }
    // Sort each day's list by time
    for (final list in byDay.values) {
      list.sort((a, b) {
        final aMin = a.time.hour * 60 + a.time.minute;
        final bMin = b.time.hour * 60 + b.time.minute;
        return aMin.compareTo(bMin);
      });
    }

    final sortedDays = byDay.keys.toList()..sort();
    final today = DateTime.now().weekday;

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 32),
      itemCount: sortedDays.length,
      itemBuilder: (context, index) {
        final day = sortedDays[index];
        final isToday = day == today;
        final classes = byDay[day]!;

        return Padding(
          padding: const EdgeInsets.only(bottom: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Day header
              Row(
                children: [
                  Text(
                    ClassSchedule.dayName(day).toUpperCase(),
                    style: TextStyle(
                      color: isToday ? kTeal : kWhite.withOpacity(0.35),
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.4,
                    ),
                  ),
                  if (isToday) ...[
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                      decoration: BoxDecoration(
                        color: kTeal.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(color: kTeal.withOpacity(0.3)),
                      ),
                      child: const Text('TODAY',
                          style: TextStyle(
                              color: kTeal,
                              fontSize: 8,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 0.8)),
                    ),
                  ],
                ],
              ),
              const SizedBox(height: 8),
              // Class cards
              Container(
                decoration: BoxDecoration(
                  color: kWhite.withOpacity(0.04),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: kWhite.withOpacity(0.08)),
                ),
                child: Column(
                  children: classes.asMap().entries.map((entry) {
                    final i = entry.key;
                    final s = entry.value;
                    return Column(
                      children: [
                        _ClassCard(schedule: s),
                        if (i < classes.length - 1)
                          Divider(
                              height: 1,
                              color: kWhite.withOpacity(0.06),
                              indent: 14,
                              endIndent: 14),
                      ],
                    );
                  }).toList(),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

// ─────────────────────────────────────────────────────────────
// Single class card
// ─────────────────────────────────────────────────────────────
class _ClassCard extends StatelessWidget {
  final ClassSchedule schedule;

  const _ClassCard({required this.schedule});

  Future<void> _confirmDelete(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1A2D5A),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('Remove Class',
            style: TextStyle(color: Color(0xFFFFFFFF), fontSize: 16, fontWeight: FontWeight.bold)),
        content: Text(
          'Remove "${schedule.name}" from your schedule?',
          style: const TextStyle(color: Color(0x66FFFFFF), fontSize: 13),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel', style: TextStyle(color: Color(0x73FFFFFF))),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Remove',
                style: TextStyle(color: Color(0xFFE87070), fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      await ClassScheduleStore.instance.remove(schedule.id);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 12, 10, 12),
      child: Row(
        children: [
          // Time pill
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
            decoration: BoxDecoration(
              color: kTeal.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: kTeal.withOpacity(0.25)),
            ),
            child: Text(
              schedule.timeLabel,
              style: const TextStyle(
                  color: kTeal, fontSize: 11, fontWeight: FontWeight.w700),
            ),
          ),
          const SizedBox(width: 12),
          // Name + room
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(schedule.name,
                    style: const TextStyle(
                        color: kWhite,
                        fontSize: 13,
                        fontWeight: FontWeight.w600)),
                if (schedule.room != null && schedule.room!.isNotEmpty) ...[
                  const SizedBox(height: 2),
                  Row(
                    children: [
                      Icon(Icons.location_on_outlined,
                          size: 11, color: kWhite.withOpacity(0.35)),
                      const SizedBox(width: 3),
                      Text(schedule.room!,
                          style: TextStyle(
                              color: kWhite.withOpacity(0.4), fontSize: 11)),
                    ],
                  ),
                ],
                const SizedBox(height: 3),
                Row(
                  children: [
                    Icon(Icons.notifications_outlined,
                        size: 11, color: kWhite.withOpacity(0.3)),
                    const SizedBox(width: 3),
                    Text('${schedule.reminderMinutes} min before',
                        style: TextStyle(
                            color: kWhite.withOpacity(0.3), fontSize: 10)),
                  ],
                ),
              ],
            ),
          ),
          // Days chips
          Wrap(
            spacing: 4,
            children: (List<int>.from(schedule.days)..sort()).map((d) {
              return Container(
                padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
                decoration: BoxDecoration(
                  color: kNavyDark.withOpacity(0.7),
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Text(ClassSchedule.dayLabel(d),
                    style: TextStyle(
                        color: kWhite.withOpacity(0.45),
                        fontSize: 9,
                        fontWeight: FontWeight.w700)),
              );
            }).toList(),
          ),
          const SizedBox(width: 4),
          // Delete
          GestureDetector(
            onTap: () => _confirmDelete(context),
            child: Container(
              width: 30, height: 30,
              decoration: BoxDecoration(
                color: const Color(0xFFE87070).withOpacity(0.08),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(Icons.delete_outline_rounded,
                  size: 16, color: const Color(0xFFE87070).withOpacity(0.6)),
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
// Empty state
// ─────────────────────────────────────────────────────────────
class _EmptyState extends StatelessWidget {
  final VoidCallback onAdd;
  const _EmptyState({required this.onAdd});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 72, height: 72,
              decoration: BoxDecoration(
                color: kTeal.withOpacity(0.1),
                shape: BoxShape.circle,
                border: Border.all(color: kTeal.withOpacity(0.2)),
              ),
              child: Icon(Icons.school_rounded, color: kTeal.withOpacity(0.6), size: 32),
            ),
            const SizedBox(height: 20),
            const Text('No Classes Yet',
                style: TextStyle(
                    color: kWhite, fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(
              'Add your class schedule and get notified before each one.',
              textAlign: TextAlign.center,
              style: TextStyle(color: kWhite.withOpacity(0.4), fontSize: 13, height: 1.5),
            ),
            const SizedBox(height: 24),
            GestureDetector(
              onTap: onAdd,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                decoration: BoxDecoration(
                  color: kTeal.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: kTeal.withOpacity(0.35)),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.add_rounded, color: kTeal, size: 18),
                    SizedBox(width: 8),
                    Text('Add a Class',
                        style: TextStyle(
                            color: kTeal,
                            fontSize: 14,
                            fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
// Add class form
// ─────────────────────────────────────────────────────────────
class _AddClassForm extends StatefulWidget {
  final VoidCallback onSaved;
  final VoidCallback onCancel;

  const _AddClassForm({super.key, required this.onSaved, required this.onCancel});

  @override
  State<_AddClassForm> createState() => _AddClassFormState();
}

class _AddClassFormState extends State<_AddClassForm> {
  final _nameController = TextEditingController();
  final _roomController = TextEditingController();

  final Set<int> _selectedDays = {};
  TimeOfDay _selectedTime = const TimeOfDay(hour: 8, minute: 0);
  int _reminderMinutes = 15;
  bool _saving = false;
  String? _error;

  static const _reminderOptions = [5, 10, 15, 30, 60];

  @override
  void dispose() {
    _nameController.dispose();
    _roomController.dispose();
    super.dispose();
  }

  String _fmtTime(TimeOfDay t) {
    final hour = t.hourOfPeriod == 0 ? 12 : t.hourOfPeriod;
    final minute = t.minute.toString().padLeft(2, '0');
    final period = t.period == DayPeriod.am ? 'AM' : 'PM';
    return '$hour:$minute $period';
  }

  Future<void> _pickTime() async {
    final picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime,
      builder: (ctx, child) => MediaQuery(
        data: MediaQuery.of(ctx).copyWith(alwaysUse24HourFormat: false),
        child: child!,
      ),
    );
    if (picked != null) setState(() => _selectedTime = picked);
  }

  Future<void> _save() async {
    final name = _nameController.text.trim();
    if (name.isEmpty) {
      setState(() => _error = 'Please enter a class name.');
      return;
    }
    if (_selectedDays.isEmpty) {
      setState(() => _error = 'Please select at least one day.');
      return;
    }
    setState(() { _saving = true; _error = null; });

    final schedule = ClassSchedule(
      id: const Uuid().v4(),
      name: name,
      days: _selectedDays.toList(),
      time: _selectedTime,
      reminderMinutes: _reminderMinutes,
      room: _roomController.text.trim().isEmpty ? null : _roomController.text.trim(),
    );

    await ClassScheduleStore.instance.add(schedule);
    if (mounted) {
      setState(() => _saving = false);
      widget.onSaved();
    }
  }

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);

    return Column(
      children: [
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                // ── Class Name ───────────────────────────
                _SectionLabel(label: 'CLASS NAME'),
                const SizedBox(height: 8),
                _InputField(
                  controller: _nameController,
                  hint: 'e.g. Data Structures',
                  icon: Icons.book_outlined,
                  onChanged: (_) => setState(() => _error = null),
                ),

                const SizedBox(height: 20),

                // ── Room (optional) ──────────────────────
                _SectionLabel(label: 'ROOM / LOCATION (OPTIONAL)'),
                const SizedBox(height: 8),
                _InputField(
                  controller: _roomController,
                  hint: 'e.g. Room 204',
                  icon: Icons.location_on_outlined,
                ),

                const SizedBox(height: 20),

                // ── Days ─────────────────────────────────
                _SectionLabel(label: 'DAYS'),
                const SizedBox(height: 10),
                Row(
                  children: List.generate(7, (i) {
                    final day = i + 1; // 1=Mon … 7=Sun
                    final selected = _selectedDays.contains(day);
                    return Expanded(
                      child: GestureDetector(
                        onTap: () {
                          setState(() {
                            _error = null;
                            if (selected) {
                              _selectedDays.remove(day);
                            } else {
                              _selectedDays.add(day);
                            }
                          });
                        },
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 150),
                          margin: EdgeInsets.only(right: i < 6 ? 5 : 0),
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          decoration: BoxDecoration(
                            color: selected
                                ? kTeal.withOpacity(0.18)
                                : kWhite.withOpacity(0.05),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: selected
                                  ? kTeal.withOpacity(0.5)
                                  : kWhite.withOpacity(0.08),
                            ),
                          ),
                          child: Text(
                            ClassSchedule.dayLabel(day),
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: selected ? kTeal : kWhite.withOpacity(0.4),
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ),
                    );
                  }),
                ),

                const SizedBox(height: 20),

                // ── Time ─────────────────────────────────
                _SectionLabel(label: 'CLASS TIME'),
                const SizedBox(height: 8),
                GestureDetector(
                  onTap: _pickTime,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                    decoration: BoxDecoration(
                      color: kWhite.withOpacity(0.04),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: kWhite.withOpacity(0.08)),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.access_time_rounded,
                            color: kTeal.withOpacity(0.8), size: 18),
                        const SizedBox(width: 10),
                        Text(
                          _fmtTime(_selectedTime),
                          style: const TextStyle(
                              color: kWhite,
                              fontSize: 15,
                              fontWeight: FontWeight.w600),
                        ),
                        const Spacer(),
                        Icon(Icons.chevron_right_rounded,
                            color: kWhite.withOpacity(0.3), size: 18),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 20),

                // ── Reminder ─────────────────────────────
                _SectionLabel(label: 'REMIND ME BEFORE'),
                const SizedBox(height: 10),
                Row(
                  children: _reminderOptions.asMap().entries.map((entry) {
                    final i = entry.key;
                    final mins = entry.value;
                    final selected = mins == _reminderMinutes;
                    final label = mins >= 60 ? '1 hr' : '$mins min';
                    return Expanded(
                      child: GestureDetector(
                        onTap: () => setState(() => _reminderMinutes = mins),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 150),
                          margin: EdgeInsets.only(right: i < _reminderOptions.length - 1 ? 8 : 0),
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          decoration: BoxDecoration(
                            color: selected
                                ? kTeal.withOpacity(0.18)
                                : kWhite.withOpacity(0.05),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: selected
                                  ? kTeal.withOpacity(0.5)
                                  : kWhite.withOpacity(0.08),
                            ),
                          ),
                          child: Text(
                            label,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: selected ? kTeal : kWhite.withOpacity(0.4),
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),

                // ── Error ─────────────────────────────────
                if (_error != null) ...[
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Icon(Icons.info_outline_rounded,
                          size: 13, color: const Color(0xFFE87070).withOpacity(0.8)),
                      const SizedBox(width: 6),
                      Text(_error!,
                          style: const TextStyle(
                              color: Color(0xFFE87070), fontSize: 12)),
                    ],
                  ),
                ],
              ],
            ),
          ),
        ),

        // ── Footer buttons ────────────────────────────────
        Divider(height: 1, color: kWhite.withOpacity(0.07)),
        Padding(
          padding: EdgeInsets.fromLTRB(16, 14, 16, 14 + mq.padding.bottom),
          child: Row(
            children: [
              // Cancel
              Expanded(
                child: GestureDetector(
                  onTap: widget.onCancel,
                  child: Container(
                    height: 50,
                    decoration: BoxDecoration(
                      color: kWhite.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: kWhite.withOpacity(0.1)),
                    ),
                    child: Center(
                      child: Text('Cancel',
                          style: TextStyle(
                              color: kWhite.withOpacity(0.55),
                              fontSize: 15,
                              fontWeight: FontWeight.w600)),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              // Save
              Expanded(
                flex: 2,
                child: GestureDetector(
                  onTap: _saving ? null : _save,
                  child: Container(
                    height: 50,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(14),
                      gradient: LinearGradient(
                        colors: [kTeal, kTeal.withOpacity(0.75)],
                      ),
                      boxShadow: [
                        BoxShadow(
                            color: kTeal.withOpacity(0.3),
                            blurRadius: 16,
                            offset: const Offset(0, 4)),
                      ],
                    ),
                    child: Center(
                      child: _saving
                          ? const SizedBox(
                              width: 18, height: 18,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2, color: Colors.white))
                          : const Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.check_rounded, color: Colors.white, size: 18),
                                SizedBox(width: 8),
                                Text('Add Class',
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 15,
                                        fontWeight: FontWeight.w700)),
                              ],
                            ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ─────────────────────────────────────────────────────────────
// Reusable sub-widgets
// ─────────────────────────────────────────────────────────────
class _SectionLabel extends StatelessWidget {
  final String label;
  const _SectionLabel({required this.label});

  @override
  Widget build(BuildContext context) {
    return Text(label,
        style: TextStyle(
            color: kWhite.withOpacity(0.35),
            fontSize: 10,
            fontWeight: FontWeight.w800,
            letterSpacing: 1.2));
  }
}

class _InputField extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final IconData icon;
  final ValueChanged<String>? onChanged;

  const _InputField({
    required this.controller,
    required this.hint,
    required this.icon,
    this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: kWhite.withOpacity(0.04),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: kWhite.withOpacity(0.08)),
      ),
      child: TextField(
        controller: controller,
        onChanged: onChanged,
        style: const TextStyle(color: kWhite, fontSize: 14),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(color: kWhite.withOpacity(0.28), fontSize: 14),
          prefixIcon: Icon(icon, color: kWhite.withOpacity(0.35), size: 18),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 14),
        ),
      ),
    );
  }
}